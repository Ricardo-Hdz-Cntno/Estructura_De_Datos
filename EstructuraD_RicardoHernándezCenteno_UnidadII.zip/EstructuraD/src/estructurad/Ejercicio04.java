/*
 *Universidad: UTNG
 *Autor: Ricardo Hernández Centeno
 *Grupo: GSI1241
 *No.Control: 1215100860
 */
package estructurad;

/**
 *
 * @author Ricardo
 */
public class Ejercicio04 {
    
     static int factorial(int numero){
          if ( numero <= 1 ) {
              return 1;
          } else {
              return numero*factorial(numero-1);
          }
     }
     public static void main(String args[]){
         System.out.println(factorial(5));
     }
 }


/*
 *Universidad: UTNG
 *Autor: Ricardo Hernández Centeno
 *Grupo: GSI1241
 *No.Control: 1215100860
 */
package estructurad;

import java.util.Scanner;

/**
 *
 * @author Ricardo
 */
public class Ejercicio07 {
    
    static String string = "";
    static int i = 0;
    
    public static String entraNumero(int n){
        String numero = String.valueOf(n);
        char num = numero.charAt(i);
        
        switch (num){
            case '0':
                string = string + "cero";
                break;
            case '1':
                string = string + "uno";
                break;
            case '2':
                string = string + "dos";
                break;
            case '3':
                string = string + "tres";
                break;
            case '4':
                string = string + "cuatro";
                break;
            case '5':
                string = string + "cinco";
                break;
            case '6':
                string = string + "seis";
                break;
            case '7':
                string = string + "siete";
                break;
            case '8':
                string = string + "ocho";
                break;
            case '9':
                string = string + "nueve";
                break;
        }
        i++;
        if (i < numero.length()) {
            Ejercicio07.entraNumero(n);
        }
        
        return string.toLowerCase();
    }
    
    public static void main(String[] args) {
        Scanner dato = new Scanner(System.in);
        System.out.println("Ingresa numero entre 1 y 999: ");
        int numero = dato.nextInt();
        
        if (numero > 0 && numero < 10000) {
            Ejercicio07 object = new Ejercicio07();
            object.entraNumero(numero);
            System.out.println(string);
        }else{
            System.out.println("Numero no valido ingrese lo que se indica en el rango");
        }
    }
    
}

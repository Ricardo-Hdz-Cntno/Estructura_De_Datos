/*
 *Universidad: UTNG
 *Autor: Ricardo Hernández Centeno
 *Grupo: GSI1241
 *No.Control: 1215100860
 */
package estructurad;

/**
 *
 * @author Ricardo
 */
public class Ejercicio05 {
    static int mcd(int m, int n) {
		if (n <= m && m % n == 0)
			return n;
		else if (m < n)
			return mcd(n, m);
		else
			return mcd(n, m % n);
	}

	public static void main(String[] args) {
		System.out.println(mcd(124,6));
	}
}
   

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Unidad2;
import javax.swing.JButton;
/**
 *
 * @author Ricardo
 */
public class CuadroMina extends JButton{
    
    private boolean mina;
    
    public CuadroMina(){
        super(); //para ejecutarlo
        //variable para el valor aleatorio
        double random = Math.random();
        
        if(random>0.9) //dificultad de minas
            mina=true;
        else
            mina=false;
        
    }
    public boolean estaMinado(){
        return mina;
    }
}

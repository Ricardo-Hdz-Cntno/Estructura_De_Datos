/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Unidad2;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Ricardo
 */
public class JuegaAdivina {
    public static void main(String[]args){
        Adivina adivina= new Adivina();
        adivina.defineArreglo(); //Se definen los datos del arreglo
        
        //mostrar arreglo
        //Scanner lector = new Scanner(System.in);
        for (int i = 0; i < 5; i++) {
            adivina.mostrarAdivinanza(0,i);
            String resp = JOptionPane.showInputDialog(adivina.mostrarAdivinanza(0, i)+"¿Que es..?");
            //System.out.println("¿Qué es....?");
            //String respuesta=lector.next();
            if (adivina.comparaRespuesta(0,i,resp)) {
                JOptionPane.showMessageDialog(null, "Es correcto, Felicidades!!!");
                //System.out.println("Es correcto, Felicidades!!!");
            }else{
                JOptionPane.showMessageDialog(null,"Lo siento tu respuesta es incorrecta");
                //System.out.println("Lo siento tu respuesta es incorrecta!!");
            }
            
        }
    }
    
}

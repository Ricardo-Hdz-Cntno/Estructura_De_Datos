/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Unidad2;

/**
 *
 * @author Ricardo
 */
public class Ventas_Mensuales {
    
    public static void main(String[] args) {
        
        int [][] ventas ={{25,20,20,50,50,30},
                          {20,15,15,90,80,90},
                          {15,10,10,40,30,40}};
        int total1=0;
        int total2=0;
        
        for (int i = 0; i < 3; i++) {
                System.out.println("");
                total1=0;
                
            for (int j = 0; j < 6; j++) {
               
                total1=total1+ventas[i][j];
            }
            System.out.print("Producción por producto:");
            System.out.print(total1);
                
        }
       
        for (int j = 0; j < 6; j++) {
                System.out.println("");
                total2=0;
            for (int i = 0; i < 3; i++) {
                
                total2=total2+ventas[i][j];
            }
            System.out.print("Produccion por mes");
            System.out.println(total2);
        }
        
        System.out.print("Enero  Febrero   Marzo   Abril   Mayo   Junio");
        for (int[] venta : ventas) {
            System.out.println("     ");
            for (int i : venta) {
                
                System.out.print("  "+i+"    ");
            }
            
        }
    }
    
}

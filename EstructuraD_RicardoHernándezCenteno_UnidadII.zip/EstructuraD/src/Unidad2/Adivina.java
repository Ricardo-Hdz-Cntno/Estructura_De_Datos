/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Unidad2;
import javax.swing.JOptionPane;
/**
 *
 * @author Ricardo
 */
public class Adivina {
    private String[][] adivinanzas;
    
    public String[][] defineArreglo(){
        String[][] muestra={{"Blanca por dentro y verde por fuera,si quires que te lo diga espera",
                            "De noche y de dia siempre estoy en la cama, en mi tu cabeza pondras para poder dormir",
                            "El roer es mi trabajo, el queso mi apetito y el gato ha sido siempre mi mas temido enemigo",
                            "lana sube,lana baja y el señor que la trabaja",
                            "Agua pasa por mi casa cate de mi corazon"},
                            {"la Pera", "la almohada","el raton","la navaja","el Aguacate"}};
        adivinanzas=muestra;
        return muestra;
    }
    
    public boolean comparaRespuesta(int ren, int col, String respuesta){
        return respuesta.equalsIgnoreCase(adivinanzas[ren+1][col]);
    }
    
    public String mostrarAdivinanza(int ren, int col){
        return adivinanzas[ren][col];
    }
    
    public String mostrarRespuesta(int ren, int col){
        return adivinanzas[ren+1][col];
    }
    
}

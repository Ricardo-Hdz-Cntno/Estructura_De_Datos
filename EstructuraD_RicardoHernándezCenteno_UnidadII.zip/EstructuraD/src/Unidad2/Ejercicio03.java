/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Unidad2;
import java.io.*;
/**
 *
 * @author Ricardo
 */
public class Ejercicio03 {
    
    public static void main(String[] a) throws Exception{
        int v[][]= new int [3][5];
        leer(v);
        visualizar(v);
    }
    static void leer(int a[][])throws Exception{
        int i,j;
        BufferedReader entrada = new BufferedReader(InputStreamReader(System.in));
        
        System.out.println("Entrada de datos de la matriz");
        for(i=0; i< a.length; i++){
        
        System.out.println("Fila: "+i);
        for(j = 0; j < a[i].length; j++)
            a[i][j]=Integer.parseInt(entrada.readLine());
    }
}

static void visualizar (int a[][]){
int i,j;
    System.out.println("\n\t Matriz leida\n");
    for(i = 0;i < a.length; i++){
        for(j=0; j<a[i].length; j++)
            System.out.println(a[i][j]+" ");
        System.out.println(" ");
    }
  }

    private static Reader InputStreamReader(InputStream in) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
